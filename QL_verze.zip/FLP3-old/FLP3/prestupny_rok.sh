#!/bin/bash

# Použití: ./script.sh rok
# Například: ./script.sh 2024

# Zkontrolujeme, zda byl zadán právě jeden argument
if [ $# -ne 1 ]; then
    echo "Použití: $0 rok"
    exit 1
fi

year=$1

# Ověření, zda je argument číslo
if ! [[ "$year" =~ ^[0-9]+$ ]]; then
    echo "Chyba: Zadejte platný celočíselný rok."
    exit 1
fi

# Podmínky pro ověření přestupného roku
if (( year % 400 == 0 )); then
    echo "$year je přestupný rok."
elif (( year % 100 == 0 )); then
    echo "$year není přestupný rok."
elif (( year % 4 == 0 )); then
    echo "$year je přestupný rok."
else
    echo "$year není přestupný rok."
fi
